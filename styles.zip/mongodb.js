const mongoose = require('mongoose');

// MongoDB connection
const mongoURI = "mongodb://localhost:27017/travelersDB"; // Replace with your MongoDB URI
mongoose.connect(mongoURI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
.then(() => console.log('MongoDB connected successfully'))
.catch(err => console.error('MongoDB connection error:', err));

// Define Mongoose Schema and Model
const travelerSchema = new mongoose.Schema({
    Fullname: { type: String, required: true },
    DateOfBirth: { type: Date, required: true },
    Gender: { type: String, required: true },
    Email: { type: String, required: true, unique: true },
    PhoneNumber: { type: String, required: true },
    Address: {
        StreetAddress: { type: String, required: true },
        City: { type: String, required: true },
        StateProvince: { type: String, required: true },
        PostalCode: { type: String, required: true },
        Country: { type: String, required: true },
    },
    TravelPreferences: {
        PreferredDestination: { type: String },
        TravelType: { type: [String] },
        PreferredTravelDates: {
            start: { type: Date },
            end: { type: Date },
        },
    },
    Username: { type: String, required: true, unique: true },
    Password: { type: String, required: true },
    FrequentFlyerNumber: { type: String },
    PreferredAirline: { type: String },
    DietaryPreferences: { type: String },
    SpecialRequests: { type: String },
    TermsAccepted: { type: Boolean, required: true },
});

const Traveler = mongoose.model('Traveler', travelerSchema);

module.exports = { Traveler };
