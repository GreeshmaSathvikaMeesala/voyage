const express = require('express');
const Traveler = require('../models/traveler');

const router = express.Router();

// Registration Route
router.post('/register', async (req, res) => {
    try {
        const {
            Fullname, DateOfBirth, Gender, Email, PhoneNumber, StreetAddress, City, StateProvince, PostalCode,
            Country, Username, Password
        } = req.body;

        const newTraveler = new Traveler({
            Fullname,
            DateOfBirth,
            Gender,
            Email,
            PhoneNumber,
            Address: { StreetAddress, City, StateProvince, PostalCode, Country },
            Username,
            Password,
        });

        // Save traveler to database
        const savedTraveler = await newTraveler.save();
        res.status(201).json({ message: 'Registration successful', data: savedTraveler });
    } catch (err) {
        console.error('Error registering traveler:', err);
        res.status(500).json({ message: 'Error registering traveler', error: err.message });
    }
});

module.exports = router;
