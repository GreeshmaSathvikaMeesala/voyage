const mongoose = require('mongoose');

const travelerSchema = new mongoose.Schema({
    Fullname: { type: String, required: true },
    DateOfBirth: { type: Date, required: true },
    Gender: { type: String, required: true },
    Email: { type: String, required: true, unique: true },
    PhoneNumber: { type: String, required: true },
    Address: {
        StreetAddress: { type: String, required: true },
        City: { type: String, required: true },
        StateProvince: { type: String, required: true },
        PostalCode: { type: String, required: true },
        Country: { type: String, required: true },
    },
    Username: { type: String, required: true, unique: true },
    Password: { type: String, required: true },
});

const Traveler = mongoose.model('Traveler', travelerSchema);
module.exports = Traveler;
